import java.time.LocalDate;

/*Question 2:
Tạo file Program.java có chứa main() method và 
khởi tạo ít nhất 3 đối tượng đối với mỗi table trong java*/

public class Program {

	public static void main(String[] args) {
		// Department
		Department department1 = new Department();
		department1.departmentID = 1;
		department1.departmentName = "Sales";
		Department department2 = new Department();
		department2.departmentID = 2;
		department2.departmentName = "Marketing";
		Department department3 = new Department();
		department3.departmentID = 3;
		department3.departmentName = "Bảo vệ";

		// Position
		Position position1 = new Position();
		position1.positionID = 1;
		position1.positionName = PositionName.Dev;
		
		Position position2 = new Position();
		position2.positionID = 2;
		position2.positionName = PositionName.Test;
		
		Position position3 = new Position();
		position3.positionID = 3;
		position3.positionName = PositionName.Scrum_Master;
		
		Position position4 = new Position();
		position4.positionID = 4;
		position4.positionName = PositionName.PM;
		
		//Tao truoc group
		Group group1 = new Group();
		group1.groupID = 1;
		group1.groupName = "Nhóm 1";
		
		Group group2 = new Group();
		group2.groupID = 2;
		group2.groupName = "Nhóm 2";
		
		Group group3 = new Group();
		group3.groupID = 3;
		group3.groupName = "Nhóm 3";
		
		//Account
		Account account1 = new Account();
		account1.accountID = 1;
		account1.email = "nguyenvana@gmail.com";
		account1.userName = "a_nguyenvan";
		account1.fullName = "Nguyễn Văn A";
		account1.department = department1;
		account1.position = position1;
		account1.createDate = LocalDate.now();
		account1.groups = new  Group[] {group1, group2};
		
		Account account2 = new Account();
		account2.accountID = 2;
		account2.email = "nguyenvanb@gmail.com";
		account2.userName = "b_nguyenvan";
		account2.fullName = "Nguyễn Văn B";
		account2.department = department2;
		account2.position = position2;
		account2.createDate = LocalDate.now();
		account2.groups = new  Group[] {group1};
		
		Account account3 = new Account();
		account3.accountID = 3;
		account3.email = "nguyenvanc@gmail.com";
		account3.userName = "c_nguyenvan";
		account3.fullName = "Nguyễn Văn C";
		account3.department = department3;
		account3.position = position3;
		account3.createDate = LocalDate.now();
		account2.groups = new  Group[] {group1};
		

		//Group creator
	
		group1.creator = account1;
		group2.creator = account1;
		group3.creator = account1;
		
		//GroupAccount
		GroupAccount gr_account1 = new GroupAccount();
		gr_account1.group = group1;
		gr_account1.account = account1;
		gr_account1.joinDate = LocalDate.of(2020,11,12);
		
		gr_account1.group = group1;
		gr_account1.account = account2;
		gr_account1.joinDate = LocalDate.of(2020,12,11);
		
		gr_account1.group = group1;
		gr_account1.account = account3;
		gr_account1.joinDate = LocalDate.of(2020,12,13);
		
		gr_account1.group = group2;
		gr_account1.account = account1;
		gr_account1.joinDate = LocalDate.of(2021,10,10);
		
		//TypeQuestion
		TypeQuestion tq1= new TypeQuestion();
		tq1.typeID = 1;
		tq1.typeName = TypeName.Essay;
		
		TypeQuestion tq2= new TypeQuestion();
		tq2.typeID = 2;
		tq2.typeName = TypeName.Multiple_Choice;
		
		//CategoryQuestion
		
		CategoryQuestion cq1 = new CategoryQuestion();
		cq1.categoryID = 1;
		cq1.categoryName = "Java";
		
		CategoryQuestion cq2 = new CategoryQuestion();
		cq2.categoryID = 2;
		cq2.categoryName = ".NET";

		CategoryQuestion cq3 = new CategoryQuestion();
		cq3.categoryID = 3;
		cq3.categoryName = "SQL";
				
		CategoryQuestion cq4 = new CategoryQuestion();
		cq4.categoryID = 4;
		cq4.categoryName = "Postman";
		
		CategoryQuestion cq5 = new CategoryQuestion();
		cq5.categoryID = 5;
		cq5.categoryName = "Ruby";
		
		
		//Question
		Question question1 = new Question();
		question1.questionID = 1;
		question1.content = "Java là gì";
		question1.category = cq1;
		question1.type = tq1;
		question1.creator = account1;
		question1.createDate = LocalDate.of(2021,01,01);
		
		Question question2 = new Question();
		question2.questionID = 2;
		question2.content = "Java được phát hành lần đầu tiên vào năm nào";
		question2.category = cq1;
		question2.type = tq2;
		question2.creator = account1;
		question2.createDate = LocalDate.of(2021,01,02);
		
		Question question3 = new Question();
		question3.questionID = 3;
		question3.content = "Java do ai tạo ra";
		question3.category = cq1;
		question3.type = tq2;
		question3.creator = account1;
		question3.createDate = LocalDate.of(2021,01,03);
		
		Question question4 = new Question();
		question4.questionID = 4;
		question4.content = "SQL là gì";
		question4.category = cq3;
		question4.type = tq1;
		question4.creator = account2;
		question4.createDate = LocalDate.of(2021,01,04);
		
		//Answer
		
		Answer answer1 = new Answer();
		answer1.answerID = 1;
		answer1.content =  "Java là ngôn ngữ lập trình bậc cao";
		answer1.question = question1;
		answer1.isCorrect = true;
		
		Answer answer2 = new Answer();
		answer2.answerID = 2;
		answer2.content =  "Java là tên một hòn đảo";
		answer2.question = question1;
		answer2.isCorrect = true;
		
		Answer answer3 = new Answer();
		answer3.answerID = 3;
		answer3.content =  "SQL là ngôn ngữ truy vấn có cấu trúc";
		answer3.question = question4;
		answer3.isCorrect = true;
		
		Answer answer4 = new Answer();
		answer4.answerID = 4;
		answer4.content =  "SQL là một phần mềm";
		answer4.question = question4;
		answer4.isCorrect = false;
		
		//Exam
		Exam exam1 = new Exam();
		exam1.examID = 1;
		exam1.code = "Java01";
		exam1.title = "Bài kiểm tra về Java 01";
		exam1.category = cq1;
		exam1.duration = "90 phút";
		exam1.creator = account1;
		exam1.createDate = LocalDate.of(2021,02,02);
		
		Exam exam2 = new Exam();
		exam2.examID = 2;
		exam2.code = "SQL01";
		exam2.title = "Bài kiểm tra về SQL 01";
		exam2.category = cq3;
		exam2.duration = "60 phút";
		exam2.creator = account2;
		exam2.createDate = LocalDate.of(2021,02,03);
		
		//ExamQuestion
		ExamQuestion eq1 = new ExamQuestion();
		eq1.exam = exam1;
		eq1.question = question1;
		
		ExamQuestion eq2 = new ExamQuestion();
		eq2.exam = exam1;
		eq2.question = question2;
		
		ExamQuestion eq3 = new ExamQuestion();
		eq3.exam = exam1;
		eq3.question = question3;
		
		ExamQuestion eq4 = new ExamQuestion();
		eq4.exam = exam2;
		eq4.question = question4;
		
		//Question 3:
		//Trong file Program.java, hãy in ít nhất 1 giá trị của mỗi đối tượng ra
		System.out.println("Thông tin của các tài khoản trong hệ thống");
		System.out.println("Tài khoản 1: ID "+ account1.accountID +
							", Email: " + account1.email +
							", UserName: " + account1.userName +
							", FullName: " + account1.fullName +
							", Department: " + account1.department.departmentName +
							", Position: " + account1.position.positionName +
							", Groups: " + account1.groups[0].groupName +", " + account1.groups[1].groupName +
							", JoinDate: " + gr_account1.joinDate);
	}
}
