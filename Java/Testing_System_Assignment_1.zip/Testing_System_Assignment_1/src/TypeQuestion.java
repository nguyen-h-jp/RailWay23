
/*Table 6: TypeQuestion
 TypeID: định danh của loại câu hỏi (auto increment)
 TypeName: tên của loại câu hỏi (Essay, Multiple-Choice)*/

public class TypeQuestion {
	int typeID;
	TypeName typeName;
}
