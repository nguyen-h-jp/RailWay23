
/*Table 1:Department
 DepartmentID: định danh của phòng ban (auto increment)
 DepartmentName: tên đầy đủ của phòng ban (VD: sale, marketing, …)
*/

public class Department {
	int departmentID;
	String departmentName;
}
