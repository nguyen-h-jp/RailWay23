
public enum TypeName {
	Essay, Multiple_Choice
}
