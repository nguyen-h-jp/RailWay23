
/*Table 7: CategoryQuestion
 CategoryID: định danh của chủ đề câu hỏi (auto increment)
 CategoryName: tên của chủ đề câu hỏi (Java, .NET, SQL, Postman, Ruby, …)*/

public class CategoryQuestion {
	int categoryID;
	String categoryName;
}
