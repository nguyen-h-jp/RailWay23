
/*Table 11: ExamQuestion
 ExamID: định danh của đề thi
 QuestionID: định danh của câu hỏi*/

public class ExamQuestion {
	Exam exam;
	Question question;
}
